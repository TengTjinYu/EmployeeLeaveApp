package com.example.employee2application

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class LobbySuper : AppCompatActivity()  {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_page_super)

        val logout = findViewById<Button>(R.id.logout)
        logout.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val leavePolicy = findViewById<Button>(R.id.leave_policy)
        leavePolicy.setOnClickListener{
            val intent = Intent(this, OTPpolicy::class.java)
            startActivity(intent)
        }

        val teamRec = findViewById<Button>(R.id.team_leave_rec)
        teamRec.setOnClickListener{
            val intent = Intent(this, OTPempRec::class.java)
            startActivity(intent)
        }
    }
}