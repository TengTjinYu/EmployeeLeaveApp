package com.example.employee2application

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class LeaveRecord : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.leave_record)

        val back = findViewById<Button>(R.id.buttonBack)
        back.setOnClickListener{
            val intent = Intent(this, Lobby::class.java)
            startActivity(intent)
        }

        val leaveInfo = findViewById<Button>(R.id.leaveInfo1)
        leaveInfo.setOnClickListener{
            val intent = Intent(this, LeaveRecInfo::class.java)
            startActivity(intent)
        }
    }
}