package com.example.employee2application

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class LeavePolicy : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.leave_policy)

        val cancel = findViewById<Button>(R.id.buttonBack)
        cancel.setOnClickListener{
            val intent = Intent(this, LobbySuper::class.java)
            startActivity(intent)
        }

        val updpol = findViewById<Button>(R.id.buttonUpdateLeave)
        updpol.setOnClickListener{
            val intent = Intent(this, LeavePolType::class.java)
            startActivity(intent)
        }

        val votepol = findViewById<Button>(R.id.buttonVoteLeavePol)
        votepol.setOnClickListener{
            val intent = Intent(this, LeavePolicyVote::class.java)
            startActivity(intent)
        }

        val polRec = findViewById<Button>(R.id.buttonLeavePolRec)
        polRec.setOnClickListener{
            val intent = Intent(this, LeavePolicyRec::class.java)
            startActivity(intent)
        }

    }
}