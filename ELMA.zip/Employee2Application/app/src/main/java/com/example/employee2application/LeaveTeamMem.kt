package com.example.employee2application

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class LeaveTeamMem : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.leave_team_member)

        val back = findViewById<Button>(R.id.buttonBack)
        back.setOnClickListener{
            val intent = Intent(this, LeaveTeamRec::class.java)
            startActivity(intent)
        }
    }
}