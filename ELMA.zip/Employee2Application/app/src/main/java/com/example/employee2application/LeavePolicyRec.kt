package com.example.employee2application

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class LeavePolicyRec : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.leave_policy_rec)

        val cancel = findViewById<Button>(R.id.buttonBack)
        cancel.setOnClickListener{
            val intent = Intent(this, LeavePolicy::class.java)
            startActivity(intent)
        }
    }
}