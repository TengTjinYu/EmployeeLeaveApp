package com.example.employee2application

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class LeaveTeamRec : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.leave_team_manage)

        val back = findViewById<Button>(R.id.buttonBack)
        back.setOnClickListener{
            val intent = Intent(this, LobbySuper::class.java)
            startActivity(intent)
        }

        val member = findViewById<Button>(R.id.buttonTeamMem1)
        member.setOnClickListener{
            val intent = Intent(this, LeaveTeamMem::class.java)
            startActivity(intent)
        }
    }
}