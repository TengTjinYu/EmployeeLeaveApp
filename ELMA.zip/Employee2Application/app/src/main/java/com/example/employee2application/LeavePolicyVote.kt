package com.example.employee2application

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class LeavePolicyVote : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.leave_policy_vote)

        val cancel = findViewById<Button>(R.id.buttonCancel)
        cancel.setOnClickListener{
            val intent = Intent(this, LeavePolicy::class.java)
            startActivity(intent)
        }

        val app = findViewById<Button>(R.id.buttonApprove)
        app.setOnClickListener{
            val intent = Intent(this, LeavePolicy::class.java)
            startActivity(intent)
        }

        val decl = findViewById<Button>(R.id.buttonDecline)
        decl.setOnClickListener{
            val intent = Intent(this, LeavePolicy::class.java)
            startActivity(intent)
        }
    }
}