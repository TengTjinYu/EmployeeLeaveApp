package com.example.employee2application

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.google.android.material.snackbar.Snackbar

class OTPempRec : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.otp_emp_recs)

        val cancel = findViewById<Button>(R.id.buttonCancel)
        cancel.setOnClickListener{
            val intent = Intent(this, LobbySuper::class.java)
            startActivity(intent)
        }

        val submit = findViewById<Button>(R.id.buttonSubmit)
        submit.setOnClickListener{
            val intent = Intent(this, LeaveTeamRec::class.java)
            startActivity(intent)
        }

        val sendOtp = findViewById<Button>(R.id.buttonOTP)
        sendOtp.setOnClickListener{
            val snack = Snackbar.make(it,"OTP Sent", Snackbar.LENGTH_SHORT)
            snack.show()
        }
    }
}