package com.example.employee2application

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Lobby : AppCompatActivity()  {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_page)

        val logout = findViewById<Button>(R.id.logout)
        logout.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val leaveform = findViewById<Button>(R.id.leaveForm)
        leaveform.setOnClickListener{
            val intent = Intent(this, LeaveForm::class.java)
            startActivity(intent)
        }

        val leaveRec = findViewById<Button>(R.id.leaveRec)
        leaveRec.setOnClickListener{
            val intent = Intent(this, LeaveRecord::class.java)
            startActivity(intent)
        }
    }
}